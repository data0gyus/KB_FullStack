let base = 100;
export const add = (x) => base + x;
export const multiply = (x) => base * x;

// export { add, multiply };
