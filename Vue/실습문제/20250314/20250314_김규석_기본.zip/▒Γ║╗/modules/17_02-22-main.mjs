import getBase, { add } from "./16_02-21-module.mjs";
console.log(add(4));
console.log(getBase());
