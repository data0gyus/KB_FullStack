const user = require('./07_user.js');
const hello = require('./08_hello.js');

console.log(user);
console.log(hello);

hello(user);