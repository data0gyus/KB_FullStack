const { user1, user2 } = require('./10_users-1.js');
const hello = require('./08_hello.js');

hello(user1);
hello(user2);