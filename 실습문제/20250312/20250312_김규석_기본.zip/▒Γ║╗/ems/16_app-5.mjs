import { goodbye } from './14_greeting-1.mjs';

goodbye("홍길동");