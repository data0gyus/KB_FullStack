import { goodbye as bye } from './12_goodbye-1.mjs';

bye('홍길동');