import { hi as hello, goodbye as bye } from './14_greeting-1.mjs';

hello('홍길동');
bye('홍길동');