import * as say from './14_greeting-1.mjs';

say.hi('홍길동');
say.goodbye('홍길동');